//Author: Lukas

public class UniPostAppApplication {

	public static Program[] programArray = new Program[281];

	public static void main(String[] args) {

		new FileImport();
		new LoginScreen();
		// new UserQuestionsAndWeightings();
		// new ReportScreen();

	}

}
