//Author: Lukas

//IMPORTS
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.Arrays;
import java.util.Comparator;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import javax.swing.JTextArea;

@SuppressWarnings("serial")
public class ReportScreen extends JFrame implements ActionListener {

	// Fields
	JFrame reportFrame = new JFrame("Report Screen");
	JPanel reportPanel = new JPanel();

	JLabel titleLabel = new JLabel("What I Think You Should Consider: ");
	JLabel background;

	// Buttons found on the screen
	JButton save = new JButton("Save");
	JButton backButton = new JButton("Back");
	JButton helpButton = new JButton("F.A.Q.");
	JButton runnerUp = new JButton("Runner - Up");
	JButton next = new JButton("Finish");

	// Array of text areas, labels, buttons
	JTextArea[] programTextArea = new JTextArea[3];
	JLabel[] programLabel = new JLabel[3];
	JLabel[] uniLabel = new JLabel[3];
	JButton[] siteButton = new JButton[3];

	// calls the different methods needed to run the screen
	public ReportScreen() {

		screenSetup();
		panelSetup();
		displayReport();

	}

	// method to display the correct information on the screen
	private void displayReport() {
		rankPrograms();
		repaint(); // updates the panel

	}

	// method that runs when the runner-up button is called
	private void RunnerUp() {
		// allows us to customize the word on the button
		Object[] site = { "Access Site" };

		// Opens up a JOptionPane and shows user the runner-up program and all it's info
		int ok = JOptionPane.showOptionDialog(reportPanel, UniPostAppApplication.programArray[3].toString(),
				"Runner-Up", JOptionPane.YES_OPTION, JOptionPane.QUESTION_MESSAGE, null, site, null);

		// if the access button is clicked
		if (ok == 0) {
			// opens the web browser and goes to the program's website
			if (Desktop.isDesktopSupported()) {
				try {
					Desktop.getDesktop().browse(new URI(UniPostAppApplication.programArray[4].getLink()));
				} catch (IOException e1) {
					e1.printStackTrace();
				} catch (URISyntaxException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	// method to rank the program
	private void rankPrograms() {

		// goes through and passes each program in our database to a
		// method to set the overall score for the program
		for (Program currentProgram : UniPostAppApplication.programArray)
			currentProgram.setOverallScore(score(currentProgram));

		// Sorts laptopArray in descending order based on overall score
		Comparator<Program> comparator = Comparator.comparing(e -> e.getOverallScore());
		Arrays.sort(UniPostAppApplication.programArray, comparator.reversed());

		// Places the correct programs and info about the programs onto the screen
		for (int index = 0; index < siteButton.length; index++) {

			programTextArea[index].setText(UniPostAppApplication.programArray[index].toString());
			programLabel[index].setText(UniPostAppApplication.programArray[index].getName());
			uniLabel[index].setText(UniPostAppApplication.programArray[index].getUniversity());

		}

	}

	// determines the overall score for each program based on the different
	// preferences
	private int score(Program currentProgram) {

		int score = 0;

		for (int x = 0; x < currentProgram.getRatings().length; x++)
			score += currentProgram.getRatings()[x];

		return score;
	}

	// sets up the screen
	public void screenSetup() {
		reportFrame.setSize(1920, 1080);

		reportFrame.setTitle("University Suggestion Program - Kajan Sivakaran - Report Screen");

		reportFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		reportFrame.setLayout(null);

		background = new JLabel(new ImageIcon("files/Report Screen Template.png"));
		background.setBounds(0, 0, 1920, 1080);
		reportFrame.add(background); // adds the background to the frame from file
	}

	// sets up the panel
	public void panelSetup() {
		reportPanel.setLayout(null);
		reportPanel.setBounds(50, 125, 1820, 800);

		// sets up and adds the different buttons onto the report panel
		save.setBounds(1050, 750, 150, 50);
		save.setFont(new Font("Comic Sans", Font.BOLD, 15));
		save.setForeground(Color.white);
		save.setBackground(new Color(0, 0, 110));
		save.addActionListener(this);
		save.setFocusable(false);

		reportPanel.add(save);

		backButton.setBounds(20, 150, 90, 50);
		backButton.setFont(new Font("Comic Sans", Font.BOLD, 15));
		backButton.setForeground(Color.black);
		backButton.setBackground(new Color(255, 255, 255));
		backButton.addActionListener(this);
		backButton.setFocusable(false);

		background.add(backButton);

		helpButton.setBounds(20, 950, 90, 50);
		helpButton.setFont(new Font("Comic Sans", Font.BOLD, 15));
		helpButton.setForeground(Color.black);
		helpButton.setBackground(new Color(255, 255, 255));
		helpButton.addActionListener(this);
		helpButton.setFocusable(false);

		background.add(helpButton);

		runnerUp.setBounds(650, 750, 190, 50);
		runnerUp.setFont(new Font("Comic Sans", Font.BOLD, 15));
		runnerUp.setForeground(Color.white);
		runnerUp.setBackground(new Color(0, 0, 110));
		runnerUp.addActionListener(this);
		runnerUp.setFocusable(false);

		reportPanel.add(runnerUp);

		next.setBounds(1720, 950, 90, 50);
		next.setFont(new Font("Comic Sans", Font.BOLD, 15));
		next.setForeground(Color.black);
		next.setBackground(new Color(255, 255, 255));
		next.addActionListener(this);
		next.setFocusable(false);

		background.add(next);

		// Sets up the 1st place, 2nd place... images
		JLabel first = new JLabel(new ImageIcon("files/FirstPlace1.png"));
		first.setBounds(-150, 110, 500, 200);

		JLabel second = new JLabel(new ImageIcon("files/second.png"));
		second.setBounds(480, 110, 500, 200);

		JLabel third = new JLabel(new ImageIcon("files/third.png"));
		third.setBounds(1100, 110, 500, 200);

		// sets up the 3 labels and text areas to display the results
		for (int index = 0; index < programTextArea.length; index++) {

			programLabel[index] = new JLabel();
			programLabel[index].setFont(new Font("helvetica", Font.BOLD, 21)); // sets the font and size of text
			programLabel[index].setForeground(new Color(250, 250, 250));
			programLabel[index].setBounds(230 + 610 * index, 180, 300, 50);

			reportPanel.add(programLabel[index]);

			uniLabel[index] = new JLabel();
			uniLabel[index].setFont(new Font("helvetica", Font.BOLD, 21)); // sets the font and size of text
			uniLabel[index].setForeground(new Color(250, 250, 250));
			uniLabel[index].setBounds(230 + 610 * index, 215, 400, 50);

			reportPanel.add(uniLabel[index]);

			siteButton[index] = new JButton("Access Website");
			siteButton[index].setFont(new Font("Comic Sans", Font.BOLD, 15));
			siteButton[index].setForeground(Color.white);
			siteButton[index].setBackground(new Color(0, 0, 110));
			siteButton[index].setBounds(170 + 620 * index, 600, 250, 50);
			siteButton[index].addActionListener(this);

			reportPanel.add(siteButton[index]);

			programTextArea[index] = new JTextArea();
			programTextArea[index].setBounds(180 + 600 * index, 290, 250, 250);

			// wraps the line so it fits into the text area and doesn't cut any words if the
			// width is too long
			programTextArea[index].setLineWrap(true);
			programTextArea[index].setWrapStyleWord(true);
			programTextArea[index].setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));

			programTextArea[index].setEditable(false); // makes sure user can't edit the text area

			reportPanel.add(programTextArea[index]); // adds the text area to panel

		}

		// sets up the title Label
		titleLabel.setBounds(450, 30, 1000, 50);
		titleLabel.setFont(new Font("helvetica", Font.BOLD, 50));
		titleLabel.setForeground(new Color(250, 250, 250));

		// adds different components onto the panel
		reportPanel.add(titleLabel);
		reportPanel.add(first);
		reportPanel.add(second);
		reportPanel.add(third);

		reportPanel.setOpaque(false); // makes the report panel transparent so we can see the background

		background.add(reportPanel);
		reportFrame.setVisible(true); // allows us to see the frame

	}

	// action performed methods - things that happen when buttons are pressed
	@Override
	public void actionPerformed(ActionEvent e) {
		// if any of the access site buttons are clicked
		// the program opens the web browser and goes to the program's website
		for (int index = 0; index < siteButton.length; index++) {
			if (e.getSource() == siteButton[index]) {

				if (Desktop.isDesktopSupported()) {
					try {
						Desktop.getDesktop().browse(new URI(UniPostAppApplication.programArray[index].getLink()));
					} catch (IOException e1) {
						e1.printStackTrace();
					} catch (URISyntaxException e1) {
						e1.printStackTrace();
					}
				}

			}
		}

		// if the back button is clicked, disposes current frame and opens the last
		// screen
		if (e.getSource() == backButton) {

			reportFrame.dispose();
			new UserQuestionsAndWeightings();
		}

		if (e.getSource() == helpButton) {
			new HelpScreen();
		}

		// Shows the runner-up program
		if (e.getSource() == runnerUp) {
			RunnerUp();
		}

		// goes to the next screen
		if (e.getSource() == next) {
			new FeedbackScreen();
			reportFrame.dispose();
		}

		if (e.getSource() == save) {
			JOptionPane.showMessageDialog(reportPanel, "This will be implemented in version 2.0");

			/*
			 * try { // creates a new file for the user File myObj = new File("files/" +
			 * LoginScreen.getUserID() + ".txt"); if (myObj.createNewFile()) {
			 * System.out.println("File Created"); // checks if the user already has a file
			 * 
			 * String data = "";
			 * 
			 * // adds the user's top 3 programs to the text file for (int i = 0; i < 3;
			 * i++) { data += UniPostAppApplication.programArray[i].toString(); }
			 * 
			 * Files.write(Paths.get(LoginScreen.getUserID() + ".txt"), data.getBytes(),
			 * StandardOpenOption.APPEND);
			 * System.out.println("succesfully wrote into file");
			 * 
			 * } else { // If the file exists, add the new programs to the text file
			 * System.out.println("File exists");
			 * 
			 * String data = "\n\n\n\n";
			 * 
			 * for (int i = 0; i < 3; i++) { data +=
			 * UniPostAppApplication.programArray[i].toString(); }
			 * 
			 * Files.write(Paths.get(LoginScreen.getUserID() + ".txt"), data.getBytes(),
			 * StandardOpenOption.APPEND);
			 * System.out.println("succesfully wrote into file"); } } catch (IOException er)
			 * { System.out.println("error occured creating new file"); }
			 */

		}

	}

}