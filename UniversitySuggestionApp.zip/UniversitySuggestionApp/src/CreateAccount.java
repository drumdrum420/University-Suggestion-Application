//Author: Lukas 

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class CreateAccount implements ActionListener {

	// fields
	public static JLabel screen;
	public static JTextField userText;
	public static JPasswordField passwordText;
	public static JPasswordField ReEnterPasswordText;
	public static JButton createAccountButton;
	public static JButton registerButton;
	public static JButton toLoginButton;
	public static JLabel success;
	public static JOptionPane retryPassword;
	public static JFrame frame = new JFrame("Create Your Account");
	public static JLabel message;

	// visual utilities
	Border blackline = BorderFactory.createLineBorder(Color.black);
	Font font1 = new Font("SansSerif", Font.PLAIN, 25);
	Font font2 = new Font("SansSerif", Font.ITALIC, 15);
	Font font3 = new Font("SansSerif", Font.BOLD, 17);

	// constructor
	public CreateAccount() {
		JPanel panel = new JPanel();
		frame.setSize(1920, 1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel);

		panel.setLayout(null);

		screen = new JLabel(new ImageIcon());
		ImageIcon backgroundphoto = new ImageIcon("files/Registration Screen Template.png");
		screen.setIcon(backgroundphoto);
		screen.setBounds(0, 0, 1920, 1080);
		panel.add(screen);

		userText = new JTextField();
		userText.setBounds(682, 490, 500, 45);
		userText.setBorder(blackline);
		userText.setFont(font1);
		screen.add(userText);

		passwordText = new JPasswordField();
		passwordText.setBounds(682, 598, 500, 45);
		passwordText.setBorder(blackline);
		passwordText.setFont(font1);
		screen.add(passwordText);

		ReEnterPasswordText = new JPasswordField();
		ReEnterPasswordText.setBounds(682, 702, 500, 45);
		ReEnterPasswordText.setBorder(blackline);
		ReEnterPasswordText.setFont(font1);
		screen.add(ReEnterPasswordText);

		createAccountButton = new JButton("Create Account");
		createAccountButton.setBounds(1055, 798, 160, 50);
		createAccountButton.setFont(font3);
		createAccountButton.setForeground(Color.WHITE);
		createAccountButton.setBackground(Color.BLUE);
		createAccountButton.addActionListener(this);
		createAccountButton.setFocusable(false);
		screen.add(createAccountButton);

		toLoginButton = new JButton("Login");
		toLoginButton.setBounds(723, 856, 100, 40);
		toLoginButton.setFont(font3);
		toLoginButton.setForeground(Color.WHITE);
		toLoginButton.setBackground(Color.BLUE);
		toLoginButton.addActionListener(this);
		toLoginButton.setFocusable(false);
		screen.add(toLoginButton);

		message = new JLabel("");
		message.setBounds(682, 420, 500, 45);
		message.setFont(font2);
		message.setForeground(Color.RED);
		screen.add(message);

		frame.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		// if create account button clicked
		if (e.getSource() == createAccountButton) {

			// Copy of the input strings
			String username = userText.getText();
			String password = String.valueOf(passwordText.getPassword());
			String password2 = String.valueOf(ReEnterPasswordText.getPassword());

			// message label reset
			message.setText(null);

			// if the username is claimed, show a message
			if (LoginScreen.getLoginInfo().containsKey(username)) {
				message.setText("Username already exists");
			}
			// if passwords don't match, show a message
			else if (!password.equals(password2)) {
				message.setText("Passwords do not match");
			}
			// otherwise, add the new account to the data.txt file and add it to the current
			// HashMap in loginScreen.java
			else {
				String userPass = username + "," + password + "\n";
				try {
					Files.write(Paths.get("files/data.txt"), userPass.getBytes(), StandardOpenOption.APPEND);
				} catch (IOException err) {
					System.out.println("error");
				}

				LoginScreen.loginInfo.put(username, password);

				// frame is closed and login screen reappears
				frame.setVisible(false);
			}

		}

		// if login button clicked, redirect back to login screen
		if (e.getSource() == toLoginButton) {
			frame.setVisible(false);
		}

	}

}