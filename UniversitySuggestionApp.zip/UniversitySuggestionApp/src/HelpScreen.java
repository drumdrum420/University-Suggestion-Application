//Author: Lukas


import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


import javax.swing.WindowConstants;

public class HelpScreen implements ActionListener {

	// fields
	
	private static JFrame frame;
	private static JButton button;

	// fields - title
	private static JLabel frequentlyLabel = new JLabel("Frequently");
	private static JLabel askedLabel = new JLabel("Asked");
	private static JLabel questionsLabel = new JLabel("Questions");

	private static JLabel background = new JLabel(new ImageIcon("files/background.png"));
	// fields - questions & answers
	private static JLabel q1text = new JLabel(
			"1. Where can I find out about details about the program I want to go into?");
	private static JLabel q2text = new JLabel(
			"2. Are my grades good enough to get accepted into the program I want to go into?");
	private static JLabel q3text = new JLabel("3. Which is the best university to apply to?");
	private static JLabel q4text = new JLabel(
			"4. If I dont have the required prerequisites for the program I want to go into, what should I do?");
	private static JLabel q5text = new JLabel(
			"5. I can't find any information on universities outside of Ontario, why is that?");
	private static JLabel q6text = new JLabel(
			"6. Will I be reconsidered for the regular program if I get rejected for the CO-OP option?");
	private static JLabel q7text = new JLabel(
			"7. Is all the information provided and displayed by this application accurate and up to date?");
	private static JLabel q8text = new JLabel(
			"8. Will I need to provide a supplementary application for the program I've selected?");

	private static JLabel a1text = new JLabel("- Call the university and ask them about their programs details ");
	private static JLabel a2text = new JLabel(
			"- Consider talking with you guidance counsellor and the university about this, also keep in mind that some");
	private static JLabel a2textcont = new JLabel(
			"programs require for supplementary applications. Your supplementary application will also be considered");
	private static JLabel a2textcont2 = new JLabel("during the acceptance process");
	private static JLabel a3text = new JLabel(
			"- It is best to consider programs you truly have an interest in and consider which is the better university");
	private static JLabel a3textcont = new JLabel("based off of your strengths and convenience.");
	private static JLabel a4text = new JLabel(
			"- Choose another program that you are eligible for or consider taking the required courses so you can be eligible for the program you've chosen.");
	private static JLabel a5text = new JLabel("- This application is limited to only Ontario universities only.");
	private static JLabel a6text = new JLabel(
			"- All univerisites have different policies about their admission procress, it is best to contact the university and ask them.");
	private static JLabel a7text = new JLabel(
			"- All data displayed is directly from the universities websites thus all information is current and based off 2021.");
	private static JLabel a8text = new JLabel(
			"- Call or check the universities website and check if a supplementary application is required for your program.");

	// constructor
	public HelpScreen() {

		// creates background
		// JPanel panel = new JPanel();
		// creates button
		background.setBounds(0, 0, 1920, 1080);
		button = new JButton("CLOSE");
		button.setFont(new Font("Sans Serif", Font.BOLD, 16));
		button.setForeground(Color.BLUE);
		button.setBounds(1215, 650, 100, 70);
		button.addActionListener(this);
		background.add(button);

		// creates Frame
		frame = new JFrame("Frequently Asked Questions");
		frame.setSize(1920, 1080);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.add(background);

		background.setLayout(null);

		// title labels added to background
		frequentlyLabel.setFont(new Font("Sans Serif", Font.BOLD, 55));
		frequentlyLabel.setBounds(45, 35, 800, 85);
		frequentlyLabel.setForeground(Color.white);
		background.add(frequentlyLabel);

		askedLabel.setFont(new Font("Sans Serif", Font.BOLD, 55));
		askedLabel.setBounds(45, 55, 400, 220);
		askedLabel.setForeground(Color.white);
		background.add(askedLabel);

		questionsLabel.setFont(new Font("Sans Serif", Font.BOLD, 55));
		questionsLabel.setBounds(45, 75, 300, 345);
		questionsLabel.setForeground(Color.white);
		background.add(questionsLabel);

		// question 1 text
		q1text.setFont(new Font("Sans Serif", Font.BOLD, 18));
		q1text.setForeground(Color.white);
		q1text.setBounds(45, 165, 800, 345);
		background.add(q1text);

		// answer 1 text
		a1text.setFont(new Font("Sans Serif", Font.PLAIN, 13));
		a1text.setForeground(Color.white);
		a1text.setBounds(53, 190, 800, 345);
		background.add(a1text);

		// question 2 text
		q2text.setFont(new Font("Gill Sans Regular", Font.BOLD, 18));
		q2text.setForeground(Color.white);
		q2text.setBounds(45, 215, 800, 345);
		background.add(q2text);

		// answer 2 text
		a2text.setFont(new Font("Sans Serif", Font.PLAIN, 13));
		a2text.setForeground(Color.white);
		a2text.setBounds(53, 240, 800, 345);
		background.add(a2text);

		a2textcont.setFont(new Font("Sans Serif", Font.PLAIN, 13));
		a2textcont.setForeground(Color.white);
		a2textcont.setBounds(53, 255, 800, 345);
		background.add(a2textcont);

		a2textcont2.setFont(new Font("Sans Serif", Font.PLAIN, 13));
		a2textcont2.setForeground(Color.white);
		a2textcont2.setBounds(53, 270, 800, 345);
		background.add(a2textcont2);

		// question 3 text
		q3text.setFont(new Font("Sans Serif", Font.BOLD, 18));
		q3text.setForeground(Color.white);
		q3text.setBounds(45, 295, 800, 345);
		background.add(q3text);

		// answer 3 text
		a3text.setFont(new Font("Sans Serif", Font.PLAIN, 13));
		a3text.setForeground(Color.white);
		a3text.setBounds(53, 315, 800, 345);
		background.add(a3text);

		a3textcont.setFont(new Font("Sans Serif", Font.PLAIN, 13));
		a3textcont.setForeground(Color.white);
		a3textcont.setBounds(53, 330, 800, 345);
		background.add(a3textcont);

		// question 4 text
		q4text.setFont(new Font("Gill Sans Regular", Font.BOLD, 18));
		q4text.setForeground(Color.white);
		q4text.setBounds(45, 355, 890, 345);
		background.add(q4text);

		// answer 4 text
		a4text.setFont(new Font("Sans Serif", Font.PLAIN, 13));
		a4text.setForeground(Color.white);
		a4text.setBounds(53, 375, 920, 345);
		background.add(a4text);

		// question 5 text
		q5text.setFont(new Font("Gill Sans Regular", Font.BOLD, 18));
		q5text.setForeground(Color.white);
		q5text.setBounds(45, 400, 800, 345);
		background.add(q5text);

		// answer 5 text
		a5text.setFont(new Font("Gill Sans Regular", Font.PLAIN, 13));
		a5text.setForeground(Color.white);
		a5text.setBounds(53, 420, 800, 345);
		background.add(a5text);

		// question 6 text
		q6text.setFont(new Font("Gill Sans Regular", Font.BOLD, 18));
		q6text.setForeground(Color.white);
		q6text.setBounds(45, 445, 815, 345);
		background.add(q6text);

		// answer 6 text
		a6text.setFont(new Font("Gill Sans Regular", Font.PLAIN, 13));
		a6text.setForeground(Color.white);
		a6text.setBounds(53, 465, 815, 345);
		background.add(a6text);

		// question 7 text
		q7text.setFont(new Font("Gill Sans Regular", Font.BOLD, 18));
		q7text.setForeground(Color.white);
		q7text.setBounds(45, 495, 860, 345);
		background.add(q7text);

		// answer 7 text
		a7text.setFont(new Font("Gill Sans Regular", Font.PLAIN, 13));
		a7text.setForeground(Color.white);
		a7text.setBounds(53, 520, 815, 345);
		background.add(a7text);

		// question 8 text
		q8text.setFont(new Font("Gill Sans Regular", Font.BOLD, 18));
		q8text.setForeground(Color.white);
		q8text.setBounds(45, 545, 800, 345);
		background.add(q8text);

		// answer 8 text
		a8text.setFont(new Font("Gill Sans Regular", Font.PLAIN, 13));
		a8text.setForeground(Color.white);
		a8text.setBounds(53, 565, 815, 345);
		background.add(a8text);

		// JLabel boss = new JLabel(new ImageIcon("files/background.png"));

		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == button) {
			frame.dispose();
		}

	}
}