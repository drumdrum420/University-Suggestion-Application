//Author: Lukas


import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;



public class FeedbackScreen implements ActionListener {

	// fields
	private static JPanel panel;
	private static JFrame frame;
	private static JButton closeButton;
	private static JButton submitButton;

	// fields - title
	private static JLabel feedback = new JLabel("Feedback!");

	// fields - feedback questions
	private static JLabel q1 = new JLabel("What did you think of this app overall? ");
	private static JLabel q2 = new JLabel("Did you have any inconveniences while interacting with the app?");
	private static JLabel q3 = new JLabel("Is there anything you think our app can need improvement with?");
	private static JLabel q4 = new JLabel("Please let us know anything else about our app below.");

	// fields - text boxes
	private static JTextField ans1 = new JTextField(40);
	private static JTextField ans2 = new JTextField(40);
	private static JTextField ans3 = new JTextField(40);
	private static JTextField ans4 = new JTextField(40);

	// fields - messages
	private static JLabel message = new JLabel("");

	public FeedbackScreen() {

		// creates panel
		panel = new JPanel();
		// creates Frame
		frame = new JFrame("Feedback!");
		frame.setSize(1920, 1080);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.add(panel);

		panel.setLayout(null);

		// title label added to panel
		feedback.setFont((new Font("Sans Serif", Font.BOLD, 75)));
		feedback.setBounds(45, 55, 400, 220);
		feedback.setForeground(Color.white);
		panel.add(feedback);

		// close application button
		closeButton = new JButton("CLOSE");
		closeButton.setFont(new Font("Sans Serif", Font.BOLD, 16));
		closeButton.setForeground(Color.BLUE);
		closeButton.setBounds(1705, 850, 100, 70);
		closeButton.addActionListener(this);
		panel.add(closeButton);

		// submit response button
		submitButton = new JButton("SUBMIT RESPONSE");
		submitButton.setFont(new Font("Sans Serif", Font.BOLD, 16));
		submitButton.setForeground(Color.BLUE);
		submitButton.setBounds(1415, 850, 235, 70);
		submitButton.addActionListener(this);
		panel.add(submitButton);

		// question 1
		q1.setFont(new Font("Sans Serif", Font.BOLD, 18));
		q1.setForeground(Color.WHITE);
		q1.setBounds(53, 130, 800, 345);
		panel.add(q1);

		// question 2
		q2.setFont(new Font("Sans Serif", Font.BOLD, 18));
		q2.setForeground(Color.WHITE);
		q2.setBounds(53, 255, 800, 345);
		panel.add(q2);

		// question 3
		q3.setFont(new Font("Sans Serif", Font.BOLD, 18));
		q3.setForeground(Color.WHITE);
		q3.setBounds(53, 380, 800, 345);
		panel.add(q3);

		// question 4
		q4.setFont(new Font("Sans Serif", Font.BOLD, 18));
		q4.setForeground(Color.WHITE);
		q4.setBounds(53, 505, 800, 345);
		panel.add(q4);

		// answer 1
		ans1.setFont(new Font("Sans Serif", Font.PLAIN, 14));
		ans1.setBounds(53, 330, 625, 75);
		ans1.setForeground(Color.BLUE);
		panel.add(ans1);

		// answer 2
		ans2.setFont(new Font("Sans Serif", Font.PLAIN, 14));
		ans2.setBounds(53, 450, 625, 75);
		ans2.setForeground(Color.BLUE);
		panel.add(ans2);

		// answer 3
		ans3.setFont(new Font("Sans Serif", Font.PLAIN, 14));
		ans3.setBounds(53, 570, 625, 75);
		ans3.setForeground(Color.BLUE);
		panel.add(ans3);

		// answer 4
		ans4.setFont(new Font("Sans Serif", Font.PLAIN, 14));
		ans4.setBounds(53, 690, 625, 120);
		ans4.setForeground(Color.BLUE);
		panel.add(ans4);

		message.setFont(new Font("Sans Serif", Font.BOLD, 14));
		message.setBounds(1025, 700, 175, 70);
		message.setForeground(Color.GREEN);
		panel.add(message);

		JLabel boss = new JLabel(new ImageIcon("files/background.png"));
		boss.setBounds(0, 0, 1920, 1080);
		panel.add(boss);
		frame.setVisible(true);

	}


	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == closeButton)
			System.exit(0);

		if (e.getSource() == submitButton) {

			String answer1 = ans1.getText();
			String answer2 = ans2.getText();
			String answer3 = ans3.getText();
			String answer4 = ans4.getText();

			String combinedAns = "What did you think of this app overall?:" + "\n" + answer1 + "\n" + "\n"
					+ "Did you have any inconveniences while interacting with the app?:" + "\n" + answer2 + "\n" + "\n"
					+ "Is there anything you think our app can need improvement with?:" + "\n" + answer3 + "\n" + "\n"
					+ "Please let us know anything else about our app below." + "\n" + answer4 + "\n\n";
			try {
				Files.write(Paths.get("feedback"), combinedAns.getBytes(), StandardOpenOption.APPEND);
				message.setText("RESPONSE SUBMITTED!");
			} catch (IOException err) {

				System.out.println("error");

			}
			JOptionPane.showMessageDialog(panel, "Response Submitted");

		}

	}

}