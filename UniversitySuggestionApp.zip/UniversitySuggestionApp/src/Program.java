//Author: Lukas
public class Program {
//fields
	private String name;
	private String university;
	private int recommendedAvg;
	private String prerequisite1;
	private String prerequisite2;
	private String prerequisite3;
	private String prerequisite4;
	private String prerequisite5;
	private double tuitionCost;
	private double distance;
	private boolean coOp;
	private int programLength;
	private String link;

	private String imageFile;
	private int[] ratings = new int[20];
	private int overallScore;

	// getters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public int getRecommendedAvg() {
		return recommendedAvg;
	}

	public void setRecommendedAvg(int recommendedAvg) {
		this.recommendedAvg = recommendedAvg;
	}

	public String getPrerequisite1() {
		return prerequisite1;
	}

	public void setPrerequisite1(String prerequisite1) {
		this.prerequisite1 = prerequisite1;
	}

	public String getPrerequisite2() {
		return prerequisite2;
	}

	public void setPrerequisite2(String prerequisite2) {
		this.prerequisite2 = prerequisite2;
	}

	public String getPrerequisite3() {
		return prerequisite3;
	}

	public void setPrerequisite3(String prerequisite3) {
		this.prerequisite3 = prerequisite3;
	}

	public String getPrerequisite4() {
		return prerequisite4;
	}

	public void setPrerequisite4(String prerequisite4) {
		this.prerequisite4 = prerequisite4;
	}

	public String getPrerequisite5() {
		return prerequisite5;
	}

	public void setPrerequisite5(String prerequisite5) {
		this.prerequisite5 = prerequisite5;
	}

	public double getTuitionCost() {
		return tuitionCost;
	}

	public void setTuitionCost(double tuitionCost) {
		this.tuitionCost = tuitionCost;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public boolean isCoOp() {
		return coOp;
	}

	public void setCoOp(boolean bool) {
		this.coOp = bool;
	}

	public int getProgramLength() {
		return programLength;
	}

	public void setProgramLength(int programLength) {
		this.programLength = programLength;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	// this method gets the image file for a suggested uni
	public String getImageFile() {
		return imageFile;
	}

	// this method sets the image file for a suggested uni
	public void setImageFile(String imageFile) {
		this.imageFile = imageFile;
	}

	// this method gets the ratings made by the user
	public int[] getRatings() {
		return ratings;
	}

	// this method sets the ratings made by the user
	public void setRatings(int[] ratings) {
		this.ratings = ratings;
	}

	// this method gets the overall score used to determine what uni should be shown
	// to the user at the end
	public int getOverallScore() {
		return overallScore;
	}

	// this method sets the overall score used to determine what uni should be shown
	// to the user at the end
	public void setOverallScore(int overallScore) {
		this.overallScore = overallScore;
	}

	// tostring
	@Override
	public String toString() {
		return "Program Name:  " + name + "\n University:  " + university + "\n Recommended Average:  " + recommendedAvg
				+ "%" + "\n Prerequisite 1:  " + prerequisite1 + "\n Prerequisite 2:  " + prerequisite2
				+ "\n Prerequisite 3:  " + prerequisite3 + "\n Prerequisite 4:  " + prerequisite4
				+ "\n Prerequisite 5:  " + prerequisite5 + "\n Tuition Cost:  $" + tuitionCost + "\n Distance:  "
				+ distance + "km" + "\n Co-Op:  " + coOp + "\n Program Length:  " + programLength + " years";
	}

}