//Author: Lukas


//imports
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.Color;

//start class
@SuppressWarnings({ "serial", "unchecked" })
public class UserQuestionsAndWeightings extends JFrame implements ActionListener {

	// fields

	private JPanel userRatingsPanel = new JPanel();
	private JButton confirmButton = new JButton();
	private JButton helpButton = new JButton("Help");

	/*
	 * Program University Avg for Admission Prerequisites Tuition Cost (Budget)
	 * Distance from Markham (km) Co-op Program Length Link
	 */

	// radio button arrays
	private JRadioButton[] programLengthButtonArray = new JRadioButton[3];
	private JRadioButton[] CoOpButtonArray = new JRadioButton[2];

	// button groups for the radio buttons
	private ButtonGroup programLengthButtonGroup = new ButtonGroup();
	private ButtonGroup CoOpButtonGroup = new ButtonGroup();

	// drop down menus
	@SuppressWarnings("rawtypes")
	private JComboBox budgetDropDown = new JComboBox();
	@SuppressWarnings("rawtypes")
	private JComboBox uniPreferenceDropDown = new JComboBox();
	@SuppressWarnings("rawtypes")
	private JComboBox averageMarkDropDown = new JComboBox();
	@SuppressWarnings("rawtypes")
	private JComboBox distanceDropDown = new JComboBox();
	@SuppressWarnings("rawtypes")
	private JComboBox facultyDropDown = new JComboBox();

	// all the jlabels and background image
	private JLabel programLengthLabel = new JLabel();
	private JLabel backgroundImageLabel = new JLabel(new ImageIcon("files/Questionairre Screen Template.png"));
	private JLabel uniPreferenceLabel = new JLabel();
	private JLabel CoOpLabel = new JLabel();
	private JLabel budgetDropDownLabel = new JLabel();
	private JLabel programTypeLabel = new JLabel();
	private JLabel averageMarkLabel = new JLabel();
	private JLabel distanceLabel = new JLabel();
	private JLabel facultyDropDownLabel = new JLabel();

	// all of the jcheckboxes for the courses our users are taking
	public static JCheckBox chemistryCheckBox = new JCheckBox("12U Chemistry (SCH4U)", false);
	public static JCheckBox bioCheckBox = new JCheckBox("12U Biology (SBI4U)", false);
	public static JCheckBox physicsCheckBox = new JCheckBox("12U Physics (SPH4U)", false);
	public static JCheckBox functionsCheckBox = new JCheckBox("12U Advanced Functions (MHF4U)", false);
	public static JCheckBox calcCheckBox = new JCheckBox("12U Calculus & Vectors (MCV4U)", false);
	public static JCheckBox englishCheckBox = new JCheckBox("12U English (ENG4U)", false);
	public static JCheckBox icsCheckBox = new JCheckBox("12U Computer Science (ICS4U)", false);

	public UserQuestionsAndWeightings() {

		userRatingsPanel();
		frameSetup();

	}

	// run everything that is needed on the user ratings panel
	private void userRatingsPanel() {

		// first add the user ratings
		userRatingsPanel.setBounds(0, 0, 1920, 1080);
		userRatingsPanel.setLayout(null);

		// then add the background image
		backgroundImageLabel.setBounds(0, 0, 1920, 1080);
		userRatingsPanel.add(backgroundImageLabel);

		// then add all of our menus and buttons
		budgetDropDownMenu();
		universityPrefsButtons();
		coOpButtons();
		programLengthButtons();
		averageMarkButtons();
		distanceButtons();
		programChoiceBoxes();
		facultyDropDownMenu();

		// add the help button
		helpButton.setBounds(20, 950, 90, 50);
		helpButton.setBackground(Color.WHITE);
		helpButton.setForeground(Color.BLACK);
		add(helpButton);
		helpButton.addActionListener(this);

		// add the confirmation button
		confirmButton.setBounds(850, 900, 200, 50);
		confirmButton.setBackground(Color.BLUE);
		confirmButton.setForeground(Color.WHITE);
		add(confirmButton);
		confirmButton.setText("Confirm");
		confirmButton.addActionListener(this);

	}

	// set up our frame
	private void frameSetup() {

		// set the size of the frame
		setSize(1920, 1080);
		setLayout(null);
		setTitle("University Suggestion Program - Lukas Bozinov - User Ratings");

		add(userRatingsPanel);

		Border greenLine = BorderFactory.createLineBorder(Color.BLUE);
		userRatingsPanel.setBorder(greenLine);

		// if the close button is pressed the program is terminated
		setDefaultCloseOperation(UserQuestionsAndWeightings.EXIT_ON_CLOSE);
		setVisible(true);
	}

	// this method sets up our drop down menu that holds distance
	public void distanceButtons() {
		// average marks
		distanceLabel.setBounds(200 + 344 + 344 + 344 + 344, 300, 300, 25);
		backgroundImageLabel.add(distanceLabel);

		distanceLabel.setText("How far away are you willing to be?");
		distanceLabel.setForeground(Color.WHITE);

		backgroundImageLabel.add(averageMarkLabel);

		distanceDropDown.addItem("Within 50km");
		distanceDropDown.addItem("Within 100km");
		distanceDropDown.addItem("Within 150km");
		distanceDropDown.addItem("Within 250km");
		distanceDropDown.addItem("Within 300km");
		distanceDropDown.addItem("Within 350km");
		distanceDropDown.addItem("Within 400km");
		distanceDropDown.addItem("Within 450km");
		distanceDropDown.addItem("Within 500km");
		distanceDropDown.addItem("More than 500km");

		distanceDropDown.addActionListener(this);

		distanceDropDown.setBackground(Color.white);
		distanceDropDown.setBounds(200 + 344 + 344 + 344 + 344, 325, 150, 25);
		backgroundImageLabel.add(distanceDropDown);
	}

	// this sets up our co-op buttons as a radio button array
	public void coOpButtons() {

		// co-op
		CoOpLabel.setBounds(200 + 344 + 344, 125, 300, 25);
		backgroundImageLabel.add(CoOpLabel);

		CoOpLabel.setText("Do you want to do co-op?");
		CoOpLabel.setForeground(Color.WHITE);

		CoOpButtonArray[0] = new JRadioButton("Yes");
		CoOpButtonArray[1] = new JRadioButton("No");

		for (int index = 0; index < CoOpButtonArray.length; index++) {

			CoOpButtonGroup.add(CoOpButtonArray[index]);
			System.out.println(index);
			CoOpButtonArray[index].setBounds(200 + 344 + 344, 150 + index * 25, 150, 25);

			backgroundImageLabel.add(CoOpButtonArray[index]);

			for (int x = 0; x < 2; x++) {
				CoOpButtonArray[x].setBackground(Color.white);
			}

			CoOpButtonArray[index].addActionListener(this);

		}

	}

	// this sets up our program length buttons as radio buttons
	public void programLengthButtons() {
		// move out
		programLengthLabel.setBounds(200 + 344 + 344 + 344, 125, 200, 25);
		backgroundImageLabel.add(programLengthLabel);

		programLengthLabel.setText("How long should your program be?");
		programLengthLabel.setForeground(Color.WHITE);

		programLengthButtonArray[0] = new JRadioButton("3 years");
		programLengthButtonArray[1] = new JRadioButton("4 years");
		programLengthButtonArray[2] = new JRadioButton("5 years");

		for (int index = 0; index < programLengthButtonArray.length; index++) {

			programLengthButtonGroup.add(programLengthButtonArray[index]);

			programLengthButtonArray[index].setBounds(200 + 344 + 344 + 344, 150 + index * 25, 150, 25);

			backgroundImageLabel.add(programLengthButtonArray[index]);

			for (int x = 0; x < 2; x++) {
				programLengthButtonArray[x].setBackground(Color.white);
			}

			programLengthButtonArray[index].addActionListener(this);
		}
	}

	// this sets up our drop down menu for the average marks that a user has
	public void averageMarkButtons() {
		// average marks
		averageMarkLabel.setBounds(200 + 344 + 344 + 344 + 344, 125, 300, 25);
		backgroundImageLabel.add(averageMarkLabel);

		averageMarkLabel.setText("What is your overall average?");
		averageMarkLabel.setForeground(Color.WHITE);

		backgroundImageLabel.add(averageMarkLabel);

		averageMarkDropDown.addItem("70% - 74.9%");
		averageMarkDropDown.addItem("75% - 79.9%");
		averageMarkDropDown.addItem("80% - 84.9%");
		averageMarkDropDown.addItem("85% - 89.9%");
		averageMarkDropDown.addItem("90%+");

		averageMarkDropDown.addActionListener(this);

		averageMarkDropDown.setBackground(Color.white);
		averageMarkDropDown.setBounds(200 + 344 + 344 + 344 + 344, 150, 150, 25);
		backgroundImageLabel.add(averageMarkDropDown);
	}

	// this dropdown lets users select a university as a preference
	public void universityPrefsButtons() {
		// university preference
		uniPreferenceLabel.setBounds(200 + 344, 125, 300, 25);
		backgroundImageLabel.add(uniPreferenceLabel);

		uniPreferenceLabel.setText("Which university do you prefer?");
		uniPreferenceLabel.setForeground(Color.WHITE);

		backgroundImageLabel.add(uniPreferenceLabel);

		uniPreferenceDropDown.addItem("Doesn't matter");
		uniPreferenceDropDown.addItem("Algoma University");
		uniPreferenceDropDown.addItem("Brock University");
		uniPreferenceDropDown.addItem("Carleton University");
		uniPreferenceDropDown.addItem("Lakehead University");
		uniPreferenceDropDown.addItem("Laurentian University");
		uniPreferenceDropDown.addItem("McMaster University");
		uniPreferenceDropDown.addItem("Nipissing University");
		uniPreferenceDropDown.addItem("Queen's University");
		uniPreferenceDropDown.addItem("Ryerson University");
		uniPreferenceDropDown.addItem("Trent University");
		uniPreferenceDropDown.addItem("University of Guelph");
		uniPreferenceDropDown.addItem("University of Ottawa");
		uniPreferenceDropDown.addItem("University of Toronto");
		uniPreferenceDropDown.addItem("University of Waterloo");
		uniPreferenceDropDown.addItem("University of Windsor");
		uniPreferenceDropDown.addItem("Western University");
		uniPreferenceDropDown.addItem("Wilfrid Laurier University");
		uniPreferenceDropDown.addItem("York University");

		uniPreferenceDropDown.addActionListener(this);

		uniPreferenceDropDown.setBackground(Color.white);
		uniPreferenceDropDown.setBounds(200 + 344, 150, 180, 25);
		backgroundImageLabel.add(uniPreferenceDropDown);
	}

	// this drop down menu sets the user's budget
	public void budgetDropDownMenu() {
		// budgeting
		budgetDropDownLabel.setBounds(200, 125, 300, 25);
		backgroundImageLabel.add(budgetDropDownLabel);

		budgetDropDownLabel.setText("What is your budget?");
		budgetDropDownLabel.setForeground(Color.WHITE);

		budgetDropDown.addItem("Up to $7500");
		budgetDropDown.addItem("Up to $10000");
		budgetDropDown.addItem("Up to $12500");
		budgetDropDown.addItem("More than $12500");

		budgetDropDown.setBackground(Color.white);
		budgetDropDown.setBounds(200, 150, 150, 25);

		backgroundImageLabel.add(budgetDropDown);
		budgetDropDown.addActionListener(this);
	}

	// this method lets the user choose faculties from the drop downs
	public void facultyDropDownMenu() {
		// faculties
		facultyDropDownLabel.setBounds(200 + 344 + 344, 300, 175, 25);
		backgroundImageLabel.add(facultyDropDownLabel);

		facultyDropDownLabel.setText("What faculty do you prefer?");
		facultyDropDownLabel.setForeground(Color.WHITE);

		facultyDropDown.addItem("No preference");
		facultyDropDown.addItem("Math");
		facultyDropDown.addItem("Biology");
		facultyDropDown.addItem("Physics");
		facultyDropDown.addItem("Chemistry");
		facultyDropDown.addItem("Computing");
		facultyDropDown.addItem("Engineering");

		facultyDropDown.setBackground(Color.white);
		facultyDropDown.setBounds(200 + 344 + 344, 325, 123, 25);

		backgroundImageLabel.add(facultyDropDown);
		facultyDropDown.addActionListener(this);
	}

	// this method selects the courses the user is taking currently
	public void programChoiceBoxes() {

		// program type
		programTypeLabel.setBounds(200, 300, 300, 25);
		backgroundImageLabel.add(programTypeLabel);
		programTypeLabel.setText("What courses are you taking currently?");
		programTypeLabel.setForeground(Color.WHITE);

		// chemistryCheckBox.setSelected(false);
		chemistryCheckBox.setBounds(200, 325, 200, 25);
		chemistryCheckBox.addActionListener(this);
		chemistryCheckBox.setBackground(Color.white);
		backgroundImageLabel.add(chemistryCheckBox);

		// bioCheckBox.setSelected(false);
		bioCheckBox.setBounds(200, 350, 200, 25);
		bioCheckBox.addActionListener(this);
		bioCheckBox.setBackground(Color.white);
		backgroundImageLabel.add(bioCheckBox);

		// physicsCheckBox.setSelected(false);
		physicsCheckBox.setBounds(200, 375, 200, 25);
		physicsCheckBox.addActionListener(this);
		physicsCheckBox.setBackground(Color.white);
		backgroundImageLabel.add(physicsCheckBox);

		// functionsCheckBox.setSelected(false);
		functionsCheckBox.setBounds(200, 400, 200, 25);
		functionsCheckBox.addActionListener(this);
		functionsCheckBox.setBackground(Color.white);
		backgroundImageLabel.add(functionsCheckBox);

		// calcCheckBox.setSelected(false);
		calcCheckBox.setBounds(200, 425, 200, 25);
		calcCheckBox.addActionListener(this);
		calcCheckBox.setBackground(Color.white);
		backgroundImageLabel.add(calcCheckBox);

		// englishCheckBox.setSelected(false);
		englishCheckBox.setBounds(200, 450, 200, 25);
		englishCheckBox.addActionListener(this);
		englishCheckBox.setBackground(Color.white);
		backgroundImageLabel.add(englishCheckBox);

		// icsCheckBox.setSelected(false);
		icsCheckBox.setBounds(200, 475, 200, 25);
		icsCheckBox.addActionListener(this);
		icsCheckBox.setBackground(Color.white);
		backgroundImageLabel.add(icsCheckBox);

	}

	@Override
	// this method runs the other methods below this one when a certain button is
	// pressed
	public void actionPerformed(ActionEvent e) {

		for (int index = 0; index < CoOpButtonArray.length; index++) {
			// checks if the click source came from the button located at index
			if (e.getSource() == CoOpButtonArray[index]) {
				setCoOpRating(index);
			}
		}

		if (e.getSource() == distanceDropDown) {
			setDistanceRating();
		}

		for (int index = 0; index < programLengthButtonArray.length; index++) {

			if (e.getSource() == programLengthButtonArray[index]) {
				setProgramLengthRating(index);
			}
		}
		if (e.getSource() == helpButton) {
			new HelpScreen();
		}

		if (e.getSource() == facultyDropDown) {
			setFacultyRating();
		}

		if (e.getSource() == budgetDropDown) {
			setBudgetRating();
		}
		if (e.getSource() == calcCheckBox) {
			setCalcRating();
		}
		if (e.getSource() == bioCheckBox) {
			setBioRating();
		}
		if (e.getSource() == physicsCheckBox) {
			setPhysicsRating();
		}
		if (e.getSource() == englishCheckBox) {
			setEnglishRating();
		}

		if (e.getSource() == functionsCheckBox) {
			setAdvFunctionsRating();
		}

		if (e.getSource() == uniPreferenceDropDown) {
			setUniPreferenceRating();
		}
		if (e.getSource() == averageMarkDropDown) {
			setAverageMarkRating();
		}
		if (e.getSource() == icsCheckBox) {
			setCompSciRating();
		}
		if (e.getSource() == chemistryCheckBox) {
			setChemistryRating();
		}

		//if all conditions to proceed to the next screen are not met, re-prompt user
		if (e.getSource() == confirmButton) {
			if (((!chemistryCheckBox.isSelected() && facultyDropDown.getSelectedIndex() == 4)
					|| (!functionsCheckBox.isSelected() && facultyDropDown.getSelectedIndex() == 1)
					|| (!bioCheckBox.isSelected() && facultyDropDown.getSelectedIndex() == 2)
					|| (!physicsCheckBox.isSelected() && facultyDropDown.getSelectedIndex() == 3))) {
				
				if (!chemistryCheckBox.isSelected() && facultyDropDown.getSelectedIndex() == 4) {
					JOptionPane.showMessageDialog(backgroundImageLabel,
							"12U Chemistry is required to go into the chemistry faculty.");

				}
				if (!functionsCheckBox.isSelected() && facultyDropDown.getSelectedIndex() == 1) {
					JOptionPane.showMessageDialog(backgroundImageLabel,
							"12U Functions is required to go into the math faculty.");

				}
				if (!bioCheckBox.isSelected() && facultyDropDown.getSelectedIndex() == 2) {
					JOptionPane.showMessageDialog(backgroundImageLabel,
							"12U Biology is required to go into the biology faculty.");

				}

				if (!physicsCheckBox.isSelected() && facultyDropDown.getSelectedIndex() == 3) {
					JOptionPane.showMessageDialog(backgroundImageLabel,
							"12U Physics is required to go into the physics faculty.");

				}//if all conditions are met, proceed to the report
			} else {
				setVisible(false);
				new ReportScreen();
			}
		}
	}

	// runs my weighting algorithm for faculties when the button is pressed
	private void setFacultyRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {

			if (facultyDropDown.getSelectedIndex() == 0) {
				if (UniPostAppApplication.programArray[index].getName().contains("")) {
					UniPostAppApplication.programArray[index].getRatings()[7] = 75; // assign 25 points to all unis with
																					// co
					// op
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}
			}
			if (facultyDropDown.getSelectedIndex() == 1) {
				if (UniPostAppApplication.programArray[index].getName().contains("Math")) {
					UniPostAppApplication.programArray[index].getRatings()[7] = 75; // assign 25 points to all unis
																					// without
					// it
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}

			}
			if (facultyDropDown.getSelectedIndex() == 2) {
				if (UniPostAppApplication.programArray[index].getName().contains("Biology")) {
					UniPostAppApplication.programArray[index].getRatings()[7] = 75; // assign 25 points to all unis
																					// without
					// it
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}

			}
			if (facultyDropDown.getSelectedIndex() == 3) {
				if (UniPostAppApplication.programArray[index].getName().contains("Physics")) {
					UniPostAppApplication.programArray[index].getRatings()[7] = 75; // assign 25 points to all unis
																					// without
					// it
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}

			}
			if (facultyDropDown.getSelectedIndex() == 4) {
				if (UniPostAppApplication.programArray[index].getName().contains("Chemistry")) {
					UniPostAppApplication.programArray[index].getRatings()[7] = 75; // assign 25 points to all unis
																					// without
					// it
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}

			}
			if (facultyDropDown.getSelectedIndex() == 5) {
				if (UniPostAppApplication.programArray[index].getName().contains("Computing")) {
					UniPostAppApplication.programArray[index].getRatings()[7] = 75; // assign 25 points to all unis
																					// without
					// it
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}

			}
			if (facultyDropDown.getSelectedIndex() == 6) {
				if (UniPostAppApplication.programArray[index].getName().contains("Engineering")) {
					UniPostAppApplication.programArray[index].getRatings()[7] = 75; // assign 25 points to all unis
																					// without
					// it
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}

			}

		}

	}

	// runs my weighting algorithm for english prerequisites when the button is
	// pressed
	private void setEnglishRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (englishCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			} else if (!englishCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("ENG4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}

			}
		}
	}

	// runs my weighting algorithm for chemistry prerequisites when the button is
	// pressed
	private void setChemistryRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (chemistryCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			} else if (!chemistryCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("SCH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			}
		}
	}

	// runs my weighting algorithm for physics prerequisites when the button is
	// pressed
	private void setPhysicsRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (physicsCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			} else if (!physicsCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("SPH4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			}
		}
	}

	// runs my weighting algorithm for biology prerequisites when the button is
	// pressed
	private void setBioRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (bioCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			} else if (!bioCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("SBI4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			}
		}
	}

	// runs my weighting algorithm for advanced functions prerequisites when the
	// button is pressed
	private void setAdvFunctionsRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (functionsCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			} else if (!functionsCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("MHF4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			}
		}
	}

	// runs my weighting algorithm for calculus and vectors prerequisites when the
	// button is pressed
	private void setCalcRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (calcCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			} else if (!calcCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());
				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("MCV4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			}
		}
	}

	// runs my weighting algorithm for computer science prerequisites when the
	// button is pressed
	private void setCompSciRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (icsCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			} else if (!icsCheckBox.isSelected()) {
				if (UniPostAppApplication.programArray[index].getPrerequisite1().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite1());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite2().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite2());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite3().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite3());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite4().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite4());

				} else if (UniPostAppApplication.programArray[index].getPrerequisite5().contains("ICS4U")) {
					UniPostAppApplication.programArray[index].getRatings()[8] = -1000000;
					System.out.println(UniPostAppApplication.programArray[index].getPrerequisite5());
				}
			}
		}

	}

	// runs my weighting algorithm for program lengths when the button is pressed
	private void setProgramLengthRating(int choice) {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {

			if (choice == 0) {
				if (UniPostAppApplication.programArray[index].getProgramLength() == 3) {
					UniPostAppApplication.programArray[index].getRatings()[3] = 25; // assign 25 points to all unis with
																					// co
					// op
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}
			}
			if (choice == 1) {
				if (UniPostAppApplication.programArray[index].getProgramLength() == 4) {
					UniPostAppApplication.programArray[index].getRatings()[3] = 25; // assign 25 points to all unis
																					// without
					// it
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}

			}
			if (choice == 2) {
				if (UniPostAppApplication.programArray[index].getProgramLength() == 5) {
					UniPostAppApplication.programArray[index].getRatings()[3] = 25; // assign 25 points to all unis
																					// without
					// it
					System.out.println(UniPostAppApplication.programArray[index].getProgramLength());
				}

			}

		}
	}// end method
		// runs my weighting algorithm for the user's average mark when the button is
		// pressed

	private void setAverageMarkRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (averageMarkDropDown.getSelectedIndex() == 0) {
				if (UniPostAppApplication.programArray[index].getRecommendedAvg() < 75
						&& UniPostAppApplication.programArray[index].getRecommendedAvg() >= 70) {
					UniPostAppApplication.programArray[index].getRatings()[6] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getRecommendedAvg());
				} else if (UniPostAppApplication.programArray[index].getRecommendedAvg() > 75) {
					UniPostAppApplication.programArray[index].getRatings()[6] = -1000000;
				}
			}
			if (averageMarkDropDown.getSelectedIndex() == 1) {
				if (UniPostAppApplication.programArray[index].getRecommendedAvg() < 80
						&& UniPostAppApplication.programArray[index].getRecommendedAvg() >= 75) {
					UniPostAppApplication.programArray[index].getRatings()[6] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getRecommendedAvg());
				} else if (UniPostAppApplication.programArray[index].getRecommendedAvg() > 80) {
					UniPostAppApplication.programArray[index].getRatings()[6] = -1000000;
				}
			}
			if (averageMarkDropDown.getSelectedIndex() == 2) {
				if (UniPostAppApplication.programArray[index].getRecommendedAvg() < 85
						&& UniPostAppApplication.programArray[index].getRecommendedAvg() >= 80) {
					UniPostAppApplication.programArray[index].getRatings()[6] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getRecommendedAvg());
				} else if (UniPostAppApplication.programArray[index].getRecommendedAvg() > 85) {
					UniPostAppApplication.programArray[index].getRatings()[6] = -1000000;
				}
			}
			if (averageMarkDropDown.getSelectedIndex() == 3) {
				if (UniPostAppApplication.programArray[index].getRecommendedAvg() < 90
						&& UniPostAppApplication.programArray[index].getRecommendedAvg() >= 85) {
					UniPostAppApplication.programArray[index].getRatings()[6] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getRecommendedAvg());
				} else if (UniPostAppApplication.programArray[index].getRecommendedAvg() > 90) {
					UniPostAppApplication.programArray[index].getRatings()[6] = -1000000;
				}
			}
			if (averageMarkDropDown.getSelectedIndex() == 4) {
				if (UniPostAppApplication.programArray[index].getRecommendedAvg() < 95
						&& UniPostAppApplication.programArray[index].getRecommendedAvg() >= 90) {
					UniPostAppApplication.programArray[index].getRatings()[6] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getRecommendedAvg());
				} else if (UniPostAppApplication.programArray[index].getRecommendedAvg() > 95) {
					UniPostAppApplication.programArray[index].getRatings()[6] = -1000000;
				}
			}
		}

	}

	// runs my weighting algorithm for university preferences when the button is
	// pressed
	private void setUniPreferenceRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (uniPreferenceDropDown.getSelectedIndex() == 0) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}
			}
			if (uniPreferenceDropDown.getSelectedIndex() == 1) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Algoma")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 2) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Brock")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 3) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Carleton")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 4) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Lakehead")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 5) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Laurentian")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 6) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("McMaster")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 7) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Nipissing")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 8) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Queen")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 9) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Ryerson")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 10) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Trent")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 11) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Guelph")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 12) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Ottawa")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 13) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Toronto")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 14) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Waterloo")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 15) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Windsor")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 16) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Western")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 17) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("Wilfrid Laurier")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}
			if (uniPreferenceDropDown.getSelectedIndex() == 18) {
				if (UniPostAppApplication.programArray[index].getUniversity().contains("York")) {
					UniPostAppApplication.programArray[index].getRatings()[19] = 75;
					System.out.println(UniPostAppApplication.programArray[index].getUniversity());
				}

			}

		}
	}

	// runs my weighting algorithm for the user's budget when the button is pressed
	private void setBudgetRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (budgetDropDown.getSelectedIndex() == 0) {
				if (UniPostAppApplication.programArray[index].getTuitionCost() <= 7500) {
					UniPostAppApplication.programArray[index].getRatings()[4] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getTuitionCost());
				}

			}
			if (budgetDropDown.getSelectedIndex() == 1) {
				if (UniPostAppApplication.programArray[index].getTuitionCost() <= 10000) {
					UniPostAppApplication.programArray[index].getRatings()[4] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getTuitionCost());
				}

			}
			if (budgetDropDown.getSelectedIndex() == 2) {
				if (UniPostAppApplication.programArray[index].getTuitionCost() <= 12500) {
					UniPostAppApplication.programArray[index].getRatings()[5] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getTuitionCost());
				}

			}
			if (budgetDropDown.getSelectedIndex() == 3) {
				if (UniPostAppApplication.programArray[index].getTuitionCost() > 12500) {
					UniPostAppApplication.programArray[index].getRatings()[4] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getTuitionCost());
				}

			}
		}
	}

	// this method sets the points given to any university that has co-op offered
	// with their program
	private void setCoOpRating(int choice) {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {

			if (choice == 0) {
				if (UniPostAppApplication.programArray[index].isCoOp() == true) {
					UniPostAppApplication.programArray[index].getRatings()[2] = 25; // assign 25 points to all unis with
																					// co
					// op
					System.out.println(UniPostAppApplication.programArray[index].toString());
				}
			}
			if (choice == 1) {
				if (UniPostAppApplication.programArray[index].isCoOp() == false) {
					UniPostAppApplication.programArray[index].getRatings()[2] = 25; // assign 25 points to all unis
																					// without
					// it
					System.out.println(UniPostAppApplication.programArray[index].toString());
				}

			}

		}
	}// end method

	// this method sets the points given to any university that is within a certain
	// radius (in km)
	private void setDistanceRating() {
		for (int index = 0; index < UniPostAppApplication.programArray.length; index++) {
			if (distanceDropDown.getSelectedIndex() == 0) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 50) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}
			if (distanceDropDown.getSelectedIndex() == 1) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 100) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}
			if (distanceDropDown.getSelectedIndex() == 2) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 150) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}
			if (distanceDropDown.getSelectedIndex() == 3) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 200) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}
			if (distanceDropDown.getSelectedIndex() == 4) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 250) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}
			if (distanceDropDown.getSelectedIndex() == 5) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 300) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}
			if (distanceDropDown.getSelectedIndex() == 6) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 350) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}
			if (distanceDropDown.getSelectedIndex() == 7) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 400) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}
			if (distanceDropDown.getSelectedIndex() == 8) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 450) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}
			if (distanceDropDown.getSelectedIndex() == 9) {
				if (UniPostAppApplication.programArray[index].getDistance() <= 500) {
					UniPostAppApplication.programArray[index].getRatings()[10] = 25;
					System.out.println(UniPostAppApplication.programArray[index].getDistance());
				}

			}

		}

	}

}// end class