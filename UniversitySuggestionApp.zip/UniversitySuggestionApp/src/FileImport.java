//Author: Lukas


//imports
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileImport {
	{

		try {
			// Create a scanner to input the data from the program csv file
			Scanner input = new Scanner(new File("files/Uni Post App2.csv"));
			input.useDelimiter(","); // used to separate each data entry

			// Start at the first program - number 0
			int index = 0;

			// Continue inputting the programs while there are more rows of data
			while (input.hasNextLine()) {

				// Create a new program
				UniPostAppApplication.programArray[index] = new Program();

				// Sets the values from the csv file as attributes for a new program
				UniPostAppApplication.programArray[index].setName(input.next());
				UniPostAppApplication.programArray[index].setUniversity(input.next());
				UniPostAppApplication.programArray[index].setRecommendedAvg(input.nextInt());
				UniPostAppApplication.programArray[index].setPrerequisite1(input.next());
				UniPostAppApplication.programArray[index].setPrerequisite2(input.next());
				UniPostAppApplication.programArray[index].setPrerequisite3(input.next());
				UniPostAppApplication.programArray[index].setPrerequisite4(input.next());
				UniPostAppApplication.programArray[index].setPrerequisite5(input.next());
				UniPostAppApplication.programArray[index].setTuitionCost(input.nextDouble());
				UniPostAppApplication.programArray[index].setDistance(input.nextDouble());
				UniPostAppApplication.programArray[index].setCoOp(input.nextBoolean());
				UniPostAppApplication.programArray[index].setProgramLength(input.nextInt());
				UniPostAppApplication.programArray[index].setLink(input.next());
				
				
				
				// Print the program to the console to test proper input
				System.out.println(UniPostAppApplication.programArray[index]);

				// Increment index counter variable for the next program index
				index++;

			}

			input.close();
		} catch (FileNotFoundException error) {

			// Provide an error message In case the file is not found
			System.out.println("Sorry file not loading - please check the name/location");

		} // End try-catch block

	}
}