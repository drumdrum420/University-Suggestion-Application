//Author: Lukas

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class LoginScreen implements ActionListener {

	// fields
	private static JLabel screen;
	private static JTextField userText;
	private static JPasswordField passwordText;
	private static JButton loginButton;
	private static JButton registerButton;
	private static JLabel success;
	public static JFrame frame = new JFrame("University Help");

	private static String userID;
	public static String password;

	// HashMap holds all the user info
	public static HashMap<String, String> loginInfo = new HashMap<String, String>();

	// visual utilities
	Border blackline = BorderFactory.createLineBorder(Color.black);
	Font font1 = new Font("SansSerif", Font.PLAIN, 25);
	Font font2 = new Font("SansSerif", Font.ITALIC, 15);
	Font font3 = new Font("SansSerif", Font.BOLD, 17);

	// constructor
	public LoginScreen() {

		// holds only username and password
		String[] userPlusPass = new String[2];

		// imports all the login info from data.txt and adds them to HashMap
		try {
			File logins = new File("files/data.txt");
			Scanner myReader = new Scanner(logins);
			while (myReader.hasNextLine()) {

				String data = myReader.nextLine();
				userPlusPass = data.split(",");

				String userTemp = userPlusPass[0];
				String passTemp = userPlusPass[1];

				loginInfo.put(userTemp, passTemp);
			}
			myReader.close();

		} catch (FileNotFoundException err) {
			System.out.println("File not found.");
		}

		JPanel panel = new JPanel();
		frame.setSize(1920, 1080);
		frame.add(panel);

		panel.setLayout(null);

		screen = new JLabel(new ImageIcon("files/Login Screen Template.png"));
		screen.setBounds(0, 0, 1920, 1080);
		panel.add(screen);

		userText = new JTextField();
		userText.setBounds(690, 555, 500, 45);
		userText.setBorder(blackline);
		userText.setFont(font1);
		screen.add(userText);

		passwordText = new JPasswordField();
		passwordText.setBounds(690, 700, 500, 45);
		passwordText.setBorder(blackline);
		passwordText.setFont(font1);
		screen.add(passwordText);

		loginButton = new JButton("Login");
		loginButton.setBounds(1035, 790, 150, 50);
		loginButton.setFont(font3);
		loginButton.setForeground(Color.WHITE);
		loginButton.setBackground(Color.BLUE);
		loginButton.setFocusable(false);
		loginButton.addActionListener(this);
		screen.add(loginButton);

		registerButton = new JButton("Create an account");
		registerButton.setBounds(675, 850, 190, 50);
		registerButton.setFont(font3);
		registerButton.setForeground(Color.WHITE);
		registerButton.setBackground(Color.BLUE);
		registerButton.setFocusable(false);
		registerButton.addActionListener(this);
		screen.add(registerButton);

		success = new JLabel("");
		success.setBounds(688, 460, 500, 45);
		success.setFont(font2);
		success.setForeground(Color.RED);
		screen.add(success);

		frame.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		// Copy of the input strings
		userID = userText.getText();
		password = String.valueOf(passwordText.getPassword());

		// reset message label
		success.setText(null);

		// when login button is clicked
		if (e.getSource() == loginButton) {
			// checks if any fields are empty
			if (userID.isEmpty() && !password.isEmpty()) {
				success.setForeground(Color.RED);
				success.setText("Username is empty");
			} else if (!userID.isEmpty() && password.isEmpty()) {
				success.setForeground(Color.RED);
				success.setText("Password is empty");
			} else if (userID.isEmpty() && password.isEmpty()) {
				success.setForeground(Color.RED);
				success.setText("Please enter a username and password");
			}

			// if none empty, check if login credentials match credentials in HashMap
			else if (loginInfo.containsKey(userID)) {
				if (loginInfo.get(userID).equals(password)) {
					success.setForeground(Color.GREEN);
					success.setText("Login Successful!");
					frame.setVisible(false);
					frame.dispose();
					new UserQuestionsAndWeightings();
				} else {
					success.setForeground(Color.RED);
					success.setText("User not found");
				}
			}
			// otherwise, user is not found
			else {
				success.setForeground(Color.RED);
				success.setText("User not found");
			}
		}

		// if register button clicked, new screen opens
		if (e.getSource() == registerButton) {
			new CreateAccount();
		}

	}

	// getters and setters
	public static HashMap<String, String> getLoginInfo() {
		return loginInfo;
	}

	public static String getUserID() {
		return userID;
	}

	public static String getPassword() {
		return password;
	}

	public static void setLoginInfo(HashMap<String, String> newInfo) {
		loginInfo = newInfo;
	}
}